-- -------- < p1AntonioChaves_Consultas > --------
--
--                    SCRIPT DE MANIPULAÇÃO (DML)
--
-- Data Criacao ...........: 01/06/2023
-- Autor(es) ..............: Antonio Rangel Chaves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: bdfinanceiro
--
-- PROJETO => 01 Base de Dados
--         => 3 Tabelas

use bdfinanceiro;
select store.`type` from store group by store.`type`;
-- AA Qual tipo de loja consegue mais vendas, essa consulta é estratégica para saber qual tipo de loja é mais rentável, e no caso
-- de um corte de verba, a diretoria poderia decidir em cortar o tipo que for menos rentável
SELECT s.`type`, sum(v.weeklysales) AS weeklysales 
FROM store s
INNER JOIN vendas_semanais v ON s.idStore = v.idStore
GROUP BY s.`type`
ORDER BY weeklysales desc;

-- É necessária a criação do índice pois é usada a cláusula group by que faz uma busca para agrupar os tipos da tabela store
CREATE INDEX store_vendas_semanais_IDX ON store(`type`);
-- | #   | SEM | COM  |
-- | 1   | 0.063 | 0.047 |